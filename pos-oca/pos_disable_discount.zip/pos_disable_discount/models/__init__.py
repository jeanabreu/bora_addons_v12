# See LICENSE file for full copyright and licensing details.

from . import pos_disable_discount
