from . import test_product_internal_category
