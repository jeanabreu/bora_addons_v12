* Mathieu Lemercier <mathieu@netandco.net>
* Franck Bret <franck@netandco.net>
* Seraphine Lantible <s.lantible@gmail.com>
* Gunnar Wagner <vrms@netcologne.de>
* Leonardo Donelli <donelli@webmonks.it>
* Serpent Consulting Services Pvt. Ltd. <jay.vora@serpentcs.com>
* Marcelo Pickler <loxamir@gmail.com>
* Andrius Laukavičius <ala@boolit.eu> (Boolit)
* Daniel Campos <danielcampos@avanzosc.es>
* `Tecnativa <https://www.tecnativa.com>`_

  * David Vidal <david.vidal@tecnativa.com>
