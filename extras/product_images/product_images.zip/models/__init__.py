# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_cron_trigger
from . import product
from . import res_config_settings
