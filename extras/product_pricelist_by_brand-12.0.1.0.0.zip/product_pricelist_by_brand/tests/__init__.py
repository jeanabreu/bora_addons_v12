###############################################################################
# For copyright and license notices, see __manifest__.py file in root directory
###############################################################################
from . import test_pricelist_by_brand
