.. _changelog:

Changelog
=========

`12.0.1.0.2`
-------
- **IMP:** Change label template.
- **FIX:** Rename model "product.label" to "print.product.label.line".


`12.0.1.0.1`
-------

- Init version
