This module adds a technical field *sanitized_vat* on partners that stores the VAT number
without spaces and with letters in uppercase. It is useful for other modules that need to
match partners on VAT number, such as the *base_business_document_import* module for example.
