This module doesn't bring any visible feature for the users.
