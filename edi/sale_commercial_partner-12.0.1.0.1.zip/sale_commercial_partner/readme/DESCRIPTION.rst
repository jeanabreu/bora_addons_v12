This module adds a related stored field *Commercial Entity* on sale orders.

This module is the twin brother of the OCA module *purchase_commercial_partner* located in the `purchase-workflow project <https://github.com/OCA/purchase-workflow/>`_.
