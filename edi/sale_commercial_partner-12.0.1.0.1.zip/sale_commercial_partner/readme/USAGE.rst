You can group by *Commercial Entity*:

* in *Sales > Sales > Quotations*,
* in *Sales > Sales > Sales Orders*,
* in *Sales > Reports > Sales* (it is a native feature in this menu)
